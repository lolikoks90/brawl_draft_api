# Brawl Draft API (Flask)

Endpoints:
- `GET /api/health` → `{"ok": true}`
- `GET /api/brawlers`
- `GET /api/maps`
- `POST /api/recommend` (form/json: mode, map, mine, enemy, bad, slot, fp)

## Deploy quick (Railway)
1. Create a new **Service → Empty**.
2. Connect repository or upload this folder.
3. Set `PORT` env var (Railway auto-provides it).
4. Deploy. Start command is in `Procfile`.

## Local run
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python app.py
# http://localhost:8080
```
